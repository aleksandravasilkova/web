package mk.ukim.finki.wp.june2022.g1.service.Impl;

import mk.ukim.finki.wp.june2022.g1.model.OSType;
import mk.ukim.finki.wp.june2022.g1.model.User;
import mk.ukim.finki.wp.june2022.g1.model.VirtualServer;
import mk.ukim.finki.wp.june2022.g1.model.exceptions.InvalidVirtualMachineIdException;
import mk.ukim.finki.wp.june2022.g1.repository.UserRepository;
import mk.ukim.finki.wp.june2022.g1.repository.VirtualServerRepository;
import mk.ukim.finki.wp.june2022.g1.service.UserService;
import mk.ukim.finki.wp.june2022.g1.service.VirtualServerService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class VirtualServerServiceImpl implements VirtualServerService {
private final UserService userService;
    private final UserRepository userRepository;
    private final VirtualServerRepository virtualServerRepository;

    public VirtualServerServiceImpl(UserService userService, UserRepository userRepository, VirtualServerRepository virtualServerRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.virtualServerRepository = virtualServerRepository;
    }

    @Override
    public List<VirtualServer> listAll() {
        return virtualServerRepository.findAll();
    }

    @Override
    public VirtualServer findById(Long id) {
        return virtualServerRepository.findById(id).orElseThrow(InvalidVirtualMachineIdException::new);
    }

    @Override
    public VirtualServer create(String name, String ipAddress, OSType osType, List<Long> owners, LocalDate launchDate) {
       List<User> owner = userRepository.findAllById(owners);
        VirtualServer virtualServer = new VirtualServer(name,ipAddress,osType,owner,launchDate);
        return virtualServerRepository.save(virtualServer);
    }

    @Override
    public VirtualServer update(Long id, String name, String ipAddress, OSType osType, List<Long> owners) {
        List<User> owner = userRepository.findAllById(owners);
        VirtualServer virtualServer = findById(id);
        virtualServer.setInstanceName(name);
        virtualServer.setIpAddress(ipAddress);
        virtualServer.setOwners(owner);
        virtualServer.setOSType(osType);

        return virtualServerRepository.save(virtualServer);
    }

    @Override
    public VirtualServer delete(Long id) {
        VirtualServer toDelete = findById(id);
        virtualServerRepository.delete(toDelete);
        return toDelete;
    }

    @Override
    public VirtualServer markTerminated(Long id) {
        VirtualServer toTerminate = findById(id);
        toTerminate.setTerminated(true);
        return virtualServerRepository.save(toTerminate);
    }

    @Override
    public List<VirtualServer> filter(Long ownerId, Integer activeMoreThanDays) {
            if(ownerId==null && activeMoreThanDays==null){
               return virtualServerRepository.findAll();
            }
            if(ownerId!=null && activeMoreThanDays!=null){
                User owner = this.userService.findById(ownerId);
                return virtualServerRepository.findByOwnersContainsAndLaunchDateBefore(owner, LocalDate.now().minusDays(activeMoreThanDays));
            }
            if(ownerId!=null){
                User owner = this.userService.findById(ownerId);
                return virtualServerRepository.findByOwnersContains(owner);

            }
else {
    return virtualServerRepository.findByLaunchDateBefore(LocalDate.now().minusDays(activeMoreThanDays));
            }




    }
}

package mk.ukim.finki.wp.jan2022.g1.model;

public enum TaskCategory {
    FEATURE,
    BUG,
    OTHER
}
